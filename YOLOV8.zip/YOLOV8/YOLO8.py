from ultralytics import YOLO
import cv2

# YOLOv8 modelini yükle
model = YOLO('yolov8n.pt')  # Küçük model

# Görüntüyü oku
img = "img/camera_img.jpeg"

# Nesne tespiti yap
results = model(img)

# Sonuçları görselleştir
for result in results:
    annotated_img = result.plot()  # plot() fonksiyonuyla sonucun çizilmesi

    # Görüntüyü OpenCV ile göster
    cv2.imshow('YOLOv8 Detection', annotated_img)
    cv2.waitKey(0)  # Bir tuşa basılana kadar bekle

cv2.destroyAllWindows()
